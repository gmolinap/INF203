"use strict";

import {fiboIt,fiboRec,fiboArr,fibMap} from "./exercise1.mjs";

console.log(fiboIt(8)); // do more that one test per function
console.log(fiboRec(7));
console.log(fiboArr([14,15]));
console.log(fibMap([14,15, 8]));